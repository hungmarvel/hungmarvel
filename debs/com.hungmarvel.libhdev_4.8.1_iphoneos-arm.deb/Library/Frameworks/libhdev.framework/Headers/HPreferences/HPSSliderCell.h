#import <Preferences/PSSpecifier.h>
#import <Preferences/PSSliderTableCell.h>
#import "../HUtilities/HCommon.h"
#import "HPSRootListController.h"

@interface HPSSliderCell : PSSliderTableCell
@end
